#numpy is being used to have the mathematical calcuations 
import numpy as np

#pandas is being used here to reading the csv file & manipulating it as Dataframe
#helps in handeling the tabular data making it suitable for task like grouping etc.
import pandas as pd

#it is used to visualize a static animated and interative plots in python
#it is used here to plot the 1D, 2D projections of the filed distributions.
import matplotlib.pyplot as plt

#All these library stated above provide high level of abstraction 
#ready to use functions and many facilities to get the work done.


#function to read the input csv file
def read_csv(file_path):
    #read file into a dataframe
    data = pd.read_csv(file_path)
    return data


#function calculated a 1D projection of the field distribution based on specified axis to keep
def calculate_1D_projection(data, axis_to_keep):
    #here it is calculating the axis_to_keep and get the mean of it
    projection = data.groupby(axis_to_keep)['field_value'].mean()
    return projection


#function to calculated a 2D projection of the field distribution while 
#eliminating one of the axes specified in the question
def calculate_2D_projection(data, axis_to_eliminate):
    #group by the axes other than axis to eliminate and calculate the mean
    #after grouping the data, mean is being calculated for each groups
    #.unstack(fill_value=0): This function reshapes the grouped data from long to wide 
    # format. It takes the innermost level of the index and pivots it to become the 
    # innermost level of the columns. fill_value=0 is used to fill any missing values 
    # with zero
    projection = data.groupby([axis for axis in ['x','y','z']if axis != axis_to_eliminate]).mean().unstack(fill_value=0)
    return projection


#this function is used to calculate the average of the fields
def calculate_average(data):
    #calculate the overall average of the field values
    average = data['field_value'].mean()
    return average


#function to plot the result of the 1D projections
def plot_1D_projection(projection):
    projection.plot()
    plt.xlabel("position along axis")
    plt.ylabel("Field value")
    plt.title("1D projection of field Distribution")
    plt.show()


#function to plot the result of the 2D projections
def plot_2D_projection(projection):
    plt.imshow(projection, cmap='viridis')
    plt.colorbar(label="Field Value")
    plt.xlabel("x-axis")
    plt.ylabel("y-axis")
    plt.title("2D projection of field Distribution")
    plt.show()


#calculating the volume of the cylinder
def calculate_volume_parameters(data, center, radius, length):
    # Extract center coordinates
    x, y, z = center
    
    # Define boundaries along x-axis for the cylindrical volume
    x_min = x - length / 2
    x_max = x + length / 2
    
    # Filter data within the cylindrical volume
    filtered_data = data[(data['x'] >= x_min) & (data['x'] <= x_max) & 
                         ((data['y'] - y)**2 + (data['z'] - z)**2 <= radius**2)]
    return filtered_data



#this function is used to restrict using of all the methods of this script
#when imported to some other script
if __name__ == "__main__":
    #taking the csv file as an input from the user
    file_path = input("enter the path to the csv file:")

    #read the csv file
    data = read_csv(file_path)

    #calculate 1D, 2D projections and average
    projection_1D = calculate_1D_projection(data, 'x')
    projection_2D = calculate_2D_projection(data, 'x')
    average = calculate_average(data)

    #plot or display the results
    plot_1D_projection(projection_1D)
    plot_2D_projection(projection_2D)
    print("Average Field Value:",average)

    # Example values
    center = (0, 0, 0)  # Center coordinates of the cylindrical volume
    radius = 5          # Radius of the cylindrical volume
    length = 10         # Length of the cylindrical volume along the x-axis

    # Call the function with the provided values
    volume_data = calculate_volume_parameters(data, center, radius, length)

