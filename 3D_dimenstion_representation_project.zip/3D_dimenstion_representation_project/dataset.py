import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import uuid

# Number of call records to generate
num_records = 10000  


# Generate random data for each feature
call_ids = [uuid.uuid4() for _ in range(num_records)]
caller_ids = [random.randint(100000, 999999) for _ in range(num_records)]
receiver_ids = [random.randint(100000, 999999) for _ in range(num_records)]
call_durations = [random.randint(30, 600) for _ in range(num_records)]  # Duration in seconds
time_of_day = [datetime.now() - timedelta(days=random.randint(0, 365)) for _ in range(num_records)]  # Random date within the past year
caller_locations = [(random.uniform(-90, 90), random.uniform(-180, 180)) for _ in range(num_records)]  # Latitude and longitude
receiver_locations = [(random.uniform(-90, 90), random.uniform(-180, 180)) for _ in range(num_records)]  # Latitude and longitude
frequency_of_calls = [random.randint(1, 5) for _ in range(num_records)]
call_outcomes = ['Answered', 'Missed', 'Voicemail']
call_outcome_probabilities = [0.6, 0.3, 0.1]  # Probability distribution for call outcomes
previous_fraud_reports = ['Yes', 'No']
previous_fraud_probabilities = [0.1, 0.9]  # Probability distribution for previous fraud reports
call_patterns = ['High call frequency during morning hours', 'No previous fraud reports', 'High call duration']

# Generate random values for each feature based on the specified distributions
call_outcomes = np.random.choice(call_outcomes, num_records, p=call_outcome_probabilities)
previous_fraud_reports = np.random.choice(previous_fraud_reports, num_records, p=previous_fraud_probabilities)
call_patterns = [random.choice(call_patterns) for _ in range(num_records)] 

# Create a DataFrame to store the generated data
data = pd.DataFrame({
    'Call ID': call_ids,
    'Caller ID': caller_ids,
    'Receiver ID': receiver_ids,
    'Call Duration': call_durations,
    'Time of Day': time_of_day,
    'Caller Location': caller_locations,
    'Receiver Location': receiver_locations,
    'Frequency of Calls': frequency_of_calls,
    'Call Outcome': call_outcomes,
    'Previous Fraud Reports': previous_fraud_reports,
    'Call Patterns': call_patterns
})

# Save the dataset to a CSV file
data.to_csv('call_records_dataset.csv', index=False)
